﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kalendarčina
{
    /// <summary>
    /// Interaction logic for AddDialog.xaml
    /// </summary>
    public partial class AddDialog : Window
    {
        public string tbTitleText, tbTagText;
        public int tbPriorityNumber;
        public DateTime? DeadlineTime;
        public string Flag; 
        public AddDialog(string flag, string oldTitle="", string oldTag="", int? oldPriorityNumber=null, DateTime? oldDeadlineTime=null)
        {
            InitializeComponent();

            Flag = flag;
            
            if (flag == "Dodaj")
            {
                tbTitle.Clear();
                tbTag.Clear();
                tbPriority.Clear();
                dpDate.SelectedDate = null;
                tbTime.Clear();
                tbTime.Text = "HH:mm:ss";
                
            }
            else if (Flag == "Uredi")
            {
                lbTitle.Content = "Uređivanje aktivnosti";
                tbTitle.Text = oldTitle;
                tbTag.Text = oldTag;
                tbPriority.Text = oldPriorityNumber?.ToString();
                dpDate.SelectedDate = oldDeadlineTime;
               
                tbTime.Text = "HH:mm:ss";
            }
        }

        public void tbTime_GotFocus(object sender, EventArgs e)
        {
            tbTime.SelectAll();
        }
       

        public void Podnesi_Click(object sender, EventArgs e)
        {

            if ((tbTitle.Text == "") || (tbPriority.Text == ""))
            {
                MessageBox.Show("Došlo je do pogreške u unosu, molim Vas da unesete i naziv aktivnosti i njen prioritet!", "Greška", MessageBoxButton.OK);
            }
            else
            {
                if(int.TryParse(tbPriority.Text, out int valuePriority))
                {
                    if (valuePriority >= 0)
                    {
                        tbTitleText = tbTitle.Text;
                        tbTagText = tbTag.Text;
                        tbPriorityNumber = valuePriority;
                        DeadlineTime = dpDate.SelectedDate;
                        if (tbTime.Text != "")
                        {
                            if(TimeOnly.TryParse(tbTime.Text, out TimeOnly valueTime))
                            {
                                DeadlineTime += TimeSpan.Parse(tbTime.Text);
                                this.DialogResult = true;
                            }
                            else
                            {
                                MessageBox.Show("Došlo je do pogreške u unosu, format vremena mora biti: \"HH:mm:ss\" !", "Greška", MessageBoxButton.OK);
                                tbTime.Focus();
                                tbTime.SelectAll();
                            }
                        }
                        else
                        {
                            this.DialogResult = true;
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Došlo je do pogreške u unosu, prioritet mora biti prirodan broj!", "Greška", MessageBoxButton.OK);
                        tbPriority.Focus();
                        tbPriority.SelectAll();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Došlo je do pogreške u unosu, prioritet mora biti prirodan broj!", "Greška", MessageBoxButton.OK);
                }
                
            }
        }
    }
}
