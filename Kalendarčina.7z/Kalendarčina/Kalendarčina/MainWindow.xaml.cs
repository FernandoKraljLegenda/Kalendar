﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalendarčina
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
         DateTime SelectedDateFromCalendar;

        private List<ToDoItem> items;
        public List<ToDoItem> Items
        {
            get { return items; }
            set
            {
                if (items != value)
                {
                    items = value;
                    OnPropertyChanged(nameof(Items));
                }
            }
        }

        private  List<ToDoItem> filteredItems;
        public List<ToDoItem> FilteredItems
        {
            get { return filteredItems; }
            set
            {
                if (filteredItems != value)
                {
                    filteredItems = value;
                    OnPropertyChanged(nameof(FilteredItems));
                }
            }
        }

        private ToDoItem lastSelectedItem;

        public MainWindow()
        {
            InitializeComponent();
            customCalendar.DateSelected += CustomCalendar_DateSelected;


            Items = new List<ToDoItem>();
            FilteredItems = new List<ToDoItem>();
            listViewTaskList.ItemsSource = Items;

            Items.Add(new ToDoItem() { Title = "Trening", Completion = true, AddedTime = DateTime.Now, DeadlineTime = DateTime.Now.AddDays(2) });
            Items.Add(new ToDoItem() { Title = "Ruskij", Completion = false, AddedTime = DateTime.Now, DeadlineTime = DateTime.Now});
            Items.Add(new ToDoItem() { Title = "Bežanica", Completion = false, AddedTime = DateTime.Now, DeadlineTime = DateTime.Now.AddDays(1), Priority = 1, Tag = "Ubojito" });
            Items.Add(new ToDoItem() { Title = "Spavanac", Completion = false, AddedTime = DateTime.Now, DeadlineTime = DateTime.Now.AddDays(1), Priority = 2, Tag = "Bezazleno" });
        }
        private void CustomCalendar_DateSelected(object sender, DateTime selectedDate)
        {
            FlagSelectedDate = "Default";
            Flag = "Filtered";
            FilterItemsByDate(selectedDate);
        }

        private void FilterItemsByDate(DateTime selectedDate)
        {
            switch (FlagSelectedDate)
            {
                case "Today":
                    lbMainWindowSubtitle.Content = "Aktivnosti - danas: ";
                    FilteredItems.Clear();
                    foreach (ToDoItem? i in Items)
                    {
                        if (i.DeadlineTime.Value.Date == DateTime.Now.Date)
                        {
                            FilteredItems.Add(i);
                        }
                    }
                    listViewTaskList.ItemsSource = FilteredItems;
                    listViewTaskList.Items.Refresh();
                    break;
                case "Past":
                    lbMainWindowSubtitle.Content = "Aktivnosti - prošle: ";
                    FilteredItems.Clear();
                    foreach (ToDoItem? i in Items)
                    {
                        if (i.DeadlineTime.Value.Date < DateTime.Now.Date)
                        {
                            FilteredItems.Add(i);
                        }
                    }
                    listViewTaskList.ItemsSource = FilteredItems;
                    listViewTaskList.Items.Refresh();
                    break;
                case "Future":
                    lbMainWindowSubtitle.Content = "Aktivnosti - nadolazeće: ";
                    FilteredItems.Clear();
                    foreach (ToDoItem? i in Items)
                    {
                        if (i.DeadlineTime.Value.Date > DateTime.Now.Date)
                        {
                            FilteredItems.Add(i);
                        }
                    }
                    listViewTaskList.ItemsSource = FilteredItems;
                    listViewTaskList.Items.Refresh();
                    break;
                case "All":
                    lbMainWindowSubtitle.Content = "Sve aktivnosti: ";
                    listViewTaskList.ItemsSource = Items;
                    listViewTaskList.Items.Refresh();
                    break;
                default:
                    lbMainWindowSubtitle.Content = "Aktivnosti -" + selectedDate.Date + ": ";
                    FilteredItems.Clear();
                    foreach (ToDoItem? i in Items)
                    {
                        if (i.DeadlineTime.Value.Date == selectedDate.Date)
                        {
                            FilteredItems.Add(i);
                        }
                    }
                    listViewTaskList.ItemsSource = FilteredItems;
                    listViewTaskList.Items.Refresh();
                    break;

            }
        }
       
        public static string Flag;
        public static string FlagSelectedDate;
        private void Danas_Click(object sender, RoutedEventArgs e)
        {
            FlagSelectedDate = "Today";
            FilterItemsByDate(DateTime.Now);
            Flag = "Filtered";
            customCalendar.SelectedDate = DateTime.Now;
            customCalendar.UpdateCalendar();
        }

        private void SveAktivnosti_Click(object sender, RoutedEventArgs e)
        {
            FlagSelectedDate = "All";
            FilterItemsByDate(DateTime.Now);
            Flag = "Default";
            customCalendar.SelectedDate = null;
            customCalendar.UpdateCalendar();
        }

        private void Nadolazeće_Click(object sender, RoutedEventArgs e)
        {
            FlagSelectedDate = "Future";
            FilterItemsByDate(DateTime.Now.AddDays(1));
            Flag = "Filtered";
            customCalendar.SelectedDate = null;
            customCalendar.UpdateCalendar();

        }

        private void Prošlo_Click(object sender, RoutedEventArgs e)
        {
            FlagSelectedDate = "Past";
            FilterItemsByDate(DateTime.Now.AddDays(-1));
            Flag = "Filtered";
            customCalendar.SelectedDate = null;
            customCalendar.UpdateCalendar();
        }
        public class ToDoItem : INotifyPropertyChanged
        {

            private string? tag;
            public string? Tag
            {
                get { return tag; }
                set
                {
                    if (tag != value)
                    {
                        tag = value;
                        OnPropertyChanged(nameof(Tag));
                    }
                }
            }

            private int? priority;
            public int? Priority
            {
                get { return priority; }
                set
                {
                    if (priority != value)
                    {
                        priority = value;
                        OnPropertyChanged(nameof(Priority));
                    }
                }
            }

            private string title;
            public string Title
            {
                get { return title; }
                set
                {
                    if (title != value)
                    {
                        title = value;
                        OnPropertyChanged(nameof(Title));
                    }
                }
            }


            private bool completion;
            public bool Completion
            {
                get { return completion; }
                set
                {
                    if (completion != value)
                    {
                        completion = value;
                        OnPropertyChanged(nameof(Completion));
                    }
                }
            }

            public DateTime AddedTime { get; set; }

            private DateTime? deadlineTime;
            public DateTime? DeadlineTime
            {
                get { return deadlineTime; }
                set
                {
                    if (deadlineTime != value)
                    {
                        deadlineTime = value;
                        OnPropertyChanged(nameof(DeadlineTime));
                    }
                }
            }

            private DateTime? completedTime;
            public DateTime? CompletedTime
            {
                get { return completedTime; }
                set
                {
                    if (completedTime != value)
                    {
                        completedTime = value;
                        OnPropertyChanged(nameof(CompletedTime));
                    }
                }
            }

            public event PropertyChangedEventHandler PropertyChanged;
            private void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void listViewTaskList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listViewTaskList.SelectedItems != null)
            {
                lastSelectedItem = listViewTaskList.SelectedItem as ToDoItem;
                Debug.WriteLine("Item selected: " + lastSelectedItem?.Title);
            }

        }

        private void listViewTaskList_SizeChanged(object sender, EventArgs e)
        {
            ListView listView = sender as ListView;
            GridView gView = listView.View as GridView;

            var workingWidth = listView.ActualWidth - SystemParameters.VerticalScrollBarWidth;

            var col1 = 0.20;
            var col2 = 0.20;
            var col3 = 0.20;
            var col4 = 0.20;
            var col5 = 0.20;
            var col6 = 0.20;
            var col7 = 0.20;


            gView.Columns[0].Width = workingWidth * col1;
            gView.Columns[1].Width = workingWidth * col2;
            gView.Columns[2].Width = workingWidth * col3;
            gView.Columns[3].Width = workingWidth * col4;
            gView.Columns[4].Width = workingWidth * col5;
            gView.Columns[5].Width = workingWidth * col6;
            gView.Columns[6].Width = workingWidth * col7;

        }

        private void Označi_Dovršeno(object sender, RoutedEventArgs e)
        {
            if(lastSelectedItem.Completion == true)
            {
                lastSelectedItem.Completion = false;
            }
            else
            {
                lastSelectedItem.Completion = true;
            }
        }

        private void Uredi_Click(object sender, EventArgs e)
        {
            AddDialog dialog = new AddDialog("Uredi", lastSelectedItem.Title, lastSelectedItem.Tag, lastSelectedItem.Priority, lastSelectedItem.DeadlineTime);
            if (dialog.ShowDialog() == true)
            {
                lastSelectedItem.Title = dialog.tbTitleText;
                lastSelectedItem.Priority = dialog.tbPriorityNumber;
                lastSelectedItem.DeadlineTime = dialog.DeadlineTime;
                lastSelectedItem.Tag = dialog.tbTagText;
            }
            listViewTaskList.Items.Refresh();
            Debug.WriteLine("Uredi Clicked");
        }

        private void Dupliciraj_Click(object sender, RoutedEventArgs e)
        {
            if (listViewTaskList.SelectedItem != null)
            {
                ToDoItem selectedItem = listViewTaskList.SelectedItem as ToDoItem;
                ToDoItem newItem = new ToDoItem() { Title = selectedItem.Title, Completion = false, AddedTime = DateTime.Now, DeadlineTime = selectedItem.DeadlineTime, CompletedTime = selectedItem.CompletedTime, Priority=selectedItem.Priority, Tag=selectedItem.Tag };
                Items.Add(newItem);
                listViewTaskList.Items.Refresh();
            }
        }

        private void Izbriši_Click(object sender, RoutedEventArgs e)
        {
            if (listViewTaskList.SelectedItem != null)
            {
                if (Flag == "Filtered")
                {
                    FilteredItems.Remove((ToDoItem)listViewTaskList.SelectedItem);
                    Items.Remove((ToDoItem)listViewTaskList.SelectedItem);
                }
                else
                {
                    Items.Remove((ToDoItem)listViewTaskList.SelectedItem);
                }

                // Update the ListView
                if (Flag == "Filtered")
                {
                    listViewTaskList.ItemsSource = FilteredItems;
                    listViewTaskList.Items.Refresh();
                }
                else
                {
                    listViewTaskList.Items.Refresh();
                }
            }
        }

        private void Oznaci_Click(object sender, RoutedEventArgs e)
        {
            if (listViewTaskList.SelectedItem != null)
            {

            }

        }


        public void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            AddDialog dialog = new AddDialog("Dodaj");

            if (dialog.ShowDialog() == true)
            {
                ToDoItem newToDoItem = new ToDoItem()
                {
                    Title = dialog.tbTitleText,
                    Priority = dialog.tbPriorityNumber,
                    DeadlineTime = dialog.DeadlineTime,
                    Tag = dialog.tbTagText,
                    Completion = false,
                    AddedTime = DateTime.Now,
                };

                Items.Add(newToDoItem);
                listViewTaskList.Items.Refresh();
            }
        }


        public CollectionView view;
        public int counter = 0;
        public ListSortDirection newDir = ListSortDirection.Ascending;
        private void listViewTaskListColumnHeader_Click(object sender, RoutedEventArgs e)
        {
            GridViewColumnHeader? column = (sender as GridViewColumnHeader);
            string? sortBy = column.Tag.ToString();

            //view = (CollectionView)CollectionViewSource.GetDefaultView(listViewTaskList.Items);
            view = (CollectionView)CollectionViewSource.GetDefaultView(items);
            view.SortDescriptions.Clear();

            Image? arrowImage = FindArrowImageByTag(sortBy);

            arrowImage.Visibility = Visibility.Visible;
            if (counter == 0)
            {
                counter++;

            }
            else if (newDir == ListSortDirection.Ascending)
            {
                newDir = ListSortDirection.Descending;
                RotateArrowImage(arrowImage, 180);
            }
            else if (newDir == ListSortDirection.Descending)
            {
                newDir = ListSortDirection.Ascending;
                RotateArrowImage(arrowImage, 0);
            }
            view.SortDescriptions.Add(new SortDescription(sortBy, newDir));

        }
        private void RotateArrowImage(Image? arrowImage, double angle)
        {
            if (arrowImage != null)
            {
                arrowImage.RenderTransformOrigin = new Point(0.5, 0.5);
                arrowImage.RenderTransform = new RotateTransform(angle);
            }
        }
        private Image? FindArrowImageByTag(string tag)
        {
            switch (tag)
            {
                case "Title":
                    return titleSortImage;
                case "AddedTime":
                    return addedTimeSortImage;
                case "DeadlineTime":
                    return deadlineTimeSortImage;
                case "CompletedTime":
                    return completedTimeSortImage;
                case "Tag":
                    return tagSortImage;
                case "Priority":
                    return prioritySortImage;
                case "Completion":
                    return completionSortImage;
                default:
                    return null;
            }
        }
    }

}
