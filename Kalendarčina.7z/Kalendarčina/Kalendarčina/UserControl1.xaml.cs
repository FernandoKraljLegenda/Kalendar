﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Shell;
using static Kalendarčina.MainWindow;

namespace Kalendarčina
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public int brojDanaUMjesecu;
        public DateTime dateTime = DateTime.Now;
        public int brojMjeseca;
        public int brojGodine;

        private DateTime? selectedDate;
        public DateTime? SelectedDate
        {
            get {  return selectedDate; }
            set
            {
                selectedDate = value;
                UpdateCalendar();
            }
        }

        public DateTime trenutnoKorištenaGodina;
        public DateTime prviDanUMjesecu;
        public int startingColumn;

        public class BtnTag
        {
            public int Month { get; set; }
            public int Year { get; set; }
        }
        public void PostaviKalendar(int brojDanaUMjesecu, int brojMjeseca, int brojGodine)
        {

            switch (brojMjeseca)
            {
                case 1:
                    mjesec.Content = "Siječanj";
                    break;
                case 2:
                    mjesec.Content = "Veljača";
                    break;
                case 3:
                    mjesec.Content = "Ožujak";
                    break;
                case 4:
                    mjesec.Content = "Travanj";
                    break;
                case 5:
                    mjesec.Content = "Svibanj";
                    break;
                case 6:
                    mjesec.Content = "Lipanj";
                    break;
                case 7:
                    mjesec.Content = "Srpanj";
                    break;
                case 8:
                    mjesec.Content = "Kolovoz";
                    break;
                case 9:
                    mjesec.Content = "Rujan";
                    break;
                case 10:
                    mjesec.Content = "Listopad";
                    break;
                case 11:
                    mjesec.Content = "Studeni";
                    break;
                case 12:
                    mjesec.Content = "Prosinac";
                    break;
            }

            trenutnoKorištenaGodina = new DateTime(brojGodine, brojMjeseca, 1);
            prviDanUMjesecu = new DateTime(brojGodine, brojMjeseca, 1);

            startingColumn = (int)prviDanUMjesecu.DayOfWeek;

            int day = 1;

            // Calculate the last day of the previous month
            DateTime lastDayOfPreviousMonth = prviDanUMjesecu.AddDays(-1);
            int lastDayOfPreviousMonthValue = DateTime.DaysInMonth(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month);

            // Calculate the last day of the focused month
            DateTime lastDayOfFocusedMonth = new DateTime(brojGodine, brojMjeseca, brojDanaUMjesecu);

            for (int row = 1; row <= 6; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    string buttonName = $"{DajRed(row)}{DajKolonu(col)}";
                    Button button = (Button)naziviIDatumi.FindName(buttonName);
                    BtnTag btnTag = new BtnTag();

                    if (row == 1 && col < startingColumn)
                    {
                        // Display the last dates of the previous month in gray
                        button.Content = (lastDayOfPreviousMonthValue - (startingColumn - col - 1)).ToString();
                        if((brojMjeseca-1)<1)
                        {
                            btnTag.Month = 12;
                            btnTag.Year = brojGodine - 1;
                            button.Tag = btnTag;
                        }
                        else
                        {
                            btnTag.Month = brojMjeseca - 1;
                            btnTag.Year = brojGodine;
                            button.Tag = btnTag;
                        }
                        button.Foreground = Brushes.Gray;
                    }
                    else if (day <= brojDanaUMjesecu)
                    {
                        btnTag.Month = brojMjeseca;
                        btnTag.Year = brojGodine;
                        button.Tag = btnTag;

                        button.Content = day.ToString();
                        day++;
                        button.Foreground = Brushes.Black; // Set the foreground color back to black for the current month's dates
                    }
                    else
                    {
                        if ((brojMjeseca + 1) > 12)
                        {
                            btnTag.Month = 1;
                            btnTag.Year = brojGodine + 1;
                            button.Tag = btnTag;
                        }
                        else
                        {
                            btnTag.Month = brojMjeseca + 1;
                            btnTag.Year = brojGodine;
                            button.Tag = btnTag;
                        }
                        // Calculate the day value for the days after the last day of the focused month
                        int dayAfterFocusedMonth = day - brojDanaUMjesecu;

                        // Display the days after the last day of the focused month in gray
                        button.Content = dayAfterFocusedMonth.ToString();
                        button.Foreground = Brushes.Gray;

                        // Increment day value
                        day++;
                    }
                    if(int.Parse(button.Content.ToString()) == DateTime.Now.Day && btnTag.Month == DateTime.Now.Month && btnTag.Year == DateTime.Now.Year)
                    {
                        button.Foreground = Brushes.Crimson;
                    }

                    
                }
            }

        }
        
        
        public void UpdateCalendar()
        {
            int day = 1;
            for (int row = 1; row <= 6; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    string buttonName = $"{DajRed(row)}{DajKolonu(col)}";
                    Button button = (Button)naziviIDatumi.FindName(buttonName);

                    // Retrieve the date associated with the button
                    BtnTag btnTag = new BtnTag();
                    btnTag = (BtnTag)button.Tag;
                    DateTime buttonDate = new DateTime(btnTag.Year, btnTag.Month, int.Parse(button.Content.ToString()));


                    // Check if the button date is the selected date
                    if (SelectedDate.HasValue && buttonDate.Date == SelectedDate.Value.Date)
                    {
                        Debug.WriteLine("Button Tag unutar UpdateCalendar = " + button.Tag);
                        Debug.WriteLine("Button date = " + buttonDate);
                        Debug.WriteLine("Selected date = " + selectedDate);
                        // Highlight the selected date
                        button.Background = Brushes.Crimson;
                    }
                    else
                    {
                        // Reset the background color
                        SolidColorBrush btnDefaultBackground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2B322E"));
                        button.Background = btnDefaultBackground;
                    }

                    

                    day++;
                }
            }
        }

        public string DajRed(int red)
        {
            return red switch
            {
                1 => "prvi",
                2 => "drugi",
                3 => "treći",
                4 => "četvrti",
                5 => "peti",
                6 => "šesti",
                _ => throw new ArgumentOutOfRangeException(nameof(red)),
            };
        }

        public string DajKolonu(int kolona)
        {
            return kolona switch
            {
                0 => "Prvi",
                1 => "Drugi",
                2 => "Treći",
                3 => "Četvrti",
                4 => "Peti",
                5 => "Šesti",
                6 => "Sedmi",
                _ => throw new ArgumentOutOfRangeException(nameof(kolona)),
            };
        }

        public UserControl1()
        {
            InitializeComponent();
            brojDanaUMjesecu = DateTime.DaysInMonth(dateTime.Year, dateTime.Month);
            brojMjeseca = dateTime.Month;
            brojGodine = dateTime.Year;
            mjesec.Content = brojMjeseca;

            PostaviKalendar(brojDanaUMjesecu, brojMjeseca, brojGodine);
        }

        private void strelicaLijevo_Click(object sender, RoutedEventArgs e)
        {
            if (brojMjeseca > 1)
            {
                brojMjeseca--;
                brojDanaUMjesecu = DateTime.DaysInMonth(brojGodine, brojMjeseca);
            }
            else
            {
                brojGodine--;
                brojMjeseca = 12;
                brojDanaUMjesecu = DateTime.DaysInMonth(brojGodine, brojMjeseca);
            }
            PostaviKalendar(brojDanaUMjesecu, brojMjeseca, brojGodine);
            UpdateCalendar();
        }

        private void strelicaDesno_Click(object sender, RoutedEventArgs e)
        {
            if (brojMjeseca < 12)
            {
                brojMjeseca++;
                brojDanaUMjesecu = DateTime.DaysInMonth(brojGodine, brojMjeseca);
            }
            else
            {
                brojGodine++;
                brojMjeseca = 1;
                brojDanaUMjesecu = DateTime.DaysInMonth(brojGodine, brojMjeseca);
            }
            PostaviKalendar(brojDanaUMjesecu, brojMjeseca, brojGodine);
            UpdateCalendar();
        }

        public event EventHandler<DateTime> DateSelected;

        public void DateButton_Clicked(object sender, RoutedEventArgs e)
        {
            Button clickedButton = (Button)sender;
            BtnTag clickedBtnTag = new BtnTag();
            clickedBtnTag = (BtnTag)clickedButton.Tag;
            DateTime clickedDate = new DateTime(clickedBtnTag.Year, clickedBtnTag.Month, int.Parse(clickedButton.Content.ToString()));
            SelectedDate = clickedDate;
            Debug.WriteLine("Button tag (month): " + clickedButton.Tag);
           
            DateSelected?.Invoke(this, clickedDate);

            
        }
    }
}

